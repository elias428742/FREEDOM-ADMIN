# ActionLogger – Fabric 26.3

Loggt alles Wichtige:

- **Kills** → Wer hat wen getötet (inkl. Source)
- **Chests / Container** → Wer hat was reingelegt oder rausgenommen
- **Advancements** → Wer hat welches Achievement freigeschaltet

Alles wird in `logs/actionlogger.log` geschrieben + in die Console.

## Build
```bash
# Java 25 nötig
./gradlew build
```
Jar liegt danach in `build/libs/actionlogger-1.0.0.jar`

## Install
Einfach in den `mods`-Ordner vom Fabric 26.3 Server werfen.

## Beispiel-Logs
```
[2026-11-18 15:42:01] [KILL] Steve killed Alex (source: player)
[2026-11-18 15:43:12] [CHEST] Steve TOOK 64x minecraft:diamond from/to generic_9x3
[2026-11-18 15:44:05] [ADVANCEMENT] Steve unlocked "Diamonds!" (minecraft:story/mine_diamond)
```

Fertig.
