package dev.dream.actionlogger.mixin;

import dev.dream.actionlogger.ActionLogger;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ScreenHandler.class)
public abstract class ScreenHandlerMixin {

    @Inject(method = "onSlotClick", at = @At("HEAD"))
    private void onSlotClick(int slotIndex, int button, SlotActionType actionType, PlayerEntity player, CallbackInfo ci) {
        if (!(player instanceof ServerPlayerEntity serverPlayer)) return;
        if (slotIndex < 0) return;

        ScreenHandler handler = (ScreenHandler) (Object) this;
        if (slotIndex >= handler.slots.size()) return;

        Slot slot = handler.slots.get(slotIndex);
        if (slot == null || slot.inventory == player.getInventory()) return; // only care about container slots

        ItemStack stack = slot.getStack();
        if (stack.isEmpty() && actionType != SlotActionType.PICKUP && actionType != SlotActionType.QUICK_MOVE) return;

        String containerName = handler.getType() != null
                ? handler.getType().toString()
                : handler.getClass().getSimpleName();

        // rough detection: if player cursor has item → putting, else taking
        ItemStack cursor = handler.getCursorStack();
        boolean tookOut = !stack.isEmpty() && (cursor.isEmpty() || actionType == SlotActionType.QUICK_MOVE);

        if (!stack.isEmpty()) {
            ActionLogger.get().onContainerChange(serverPlayer, containerName, stack.copy(), tookOut);
        } else if (!cursor.isEmpty()) {
            ActionLogger.get().onContainerChange(serverPlayer, containerName, cursor.copy(), false);
        }
    }
}
