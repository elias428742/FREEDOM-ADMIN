package dev.dream.actionlogger;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.advancement.AdvancementEntry;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class ActionLogger implements ModInitializer {

    public static final String MOD_ID = "actionlogger";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static ActionLogger INSTANCE;
    private Path logFile;
    private MinecraftServer server;

    // Track open containers for chest logging
    public final Map<UUID, String> openContainers = new ConcurrentHashMap<>();

    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @Override
    public void onInitialize() {
        INSTANCE = this;
        logFile = FabricLoader.getInstance().getGameDir().resolve("logs").resolve("actionlogger.log");

        try {
            Files.createDirectories(logFile.getParent());
            if (!Files.exists(logFile)) {
                Files.createFile(logFile);
            }
        } catch (IOException e) {
            LOGGER.error("Could not create log file", e);
        }

        ServerLifecycleEvents.SERVER_STARTED.register(s -> this.server = s);

        // === KILLS ===
        ServerLivingEntityEvents.AFTER_DEATH.register(this::onDeath);

        // === ADVANCEMENTS ===
        // Fabric has no perfect high-level event for every advancement grant in all versions,
        // therefore we also log via a small helper that can be called from mixins if needed.
        // For 26.3 we use the player advancement tracker change via a simple poll + event combo.
        // Clean way: Mixin on PlayerAdvancementTracker or use the callback if available.

        LOGGER.info("[ActionLogger] Loaded – logging kills, chests & advancements to logs/actionlogger.log");
    }

    private void onDeath(LivingEntity entity, DamageSource source) {
        if (!(entity instanceof ServerPlayerEntity victim)) return;

        String killerName = "Unknown / Environment";
        if (source.getAttacker() instanceof PlayerEntity killer) {
            killerName = killer.getName().getString();
        } else if (source.getAttacker() != null) {
            killerName = source.getAttacker().getName().getString();
        } else if (source.getName() != null) {
            killerName = source.getName();
        }

        String msg = String.format("[KILL] %s killed %s (source: %s)",
                killerName,
                victim.getName().getString(),
                source.getName() != null ? source.getName() : "unknown");

        log(msg);
    }

    /** Called when a player unlocks an advancement */
    public void onAdvancement(ServerPlayerEntity player, AdvancementEntry advancement) {
        Identifier id = advancement.id();
        String title = advancement.value().display().map(d -> d.getTitle().getString()).orElse(id.toString());

        String msg = String.format("[ADVANCEMENT] %s unlocked \"%s\" (%s)",
                player.getName().getString(),
                title,
                id.toString());

        log(msg);
    }

    /** Called from ScreenHandlerMixin when items move in/out of a container */
    public void onContainerChange(ServerPlayerEntity player, String containerName, ItemStack stack, boolean tookOut) {
        if (stack.isEmpty()) return;

        String action = tookOut ? "TOOK" : "PUT";
        String msg = String.format("[CHEST] %s %s %dx %s from/to %s",
                player.getName().getString(),
                action,
                stack.getCount(),
                stack.getItem().toString(),
                containerName);

        log(msg);
    }

    public void log(String message) {
        String line = "[" + LocalDateTime.now().format(TIME) + "] " + message;
        LOGGER.info(line);

        try (BufferedWriter writer = Files.newBufferedWriter(logFile,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            writer.write(line);
            writer.newLine();
        } catch (IOException e) {
            LOGGER.error("Failed to write log", e);
        }
    }

    public static ActionLogger get() {
        return INSTANCE;
    }
}
